package com.example.farmacia;

public interface CommandExecution {
    void execute(String command);
}
