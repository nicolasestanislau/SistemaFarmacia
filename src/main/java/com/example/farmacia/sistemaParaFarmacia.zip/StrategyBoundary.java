package com.example.farmacia;

import javafx.scene.layout.Pane;

public interface StrategyBoundary {
    Pane render();
}
